export default function footer(){
    return (
        <div className="text-dark text-center m-0 sticky-end mt-4" style={{backgroundColor: "#8FBC8B", height: "90px",width: "100%", textAlign: "center", padding: "30px"}}>
            <b className="mb-0">&copy; 2025 Kerala Tourism. All rights reserved.</b>
        </div>
    );
}