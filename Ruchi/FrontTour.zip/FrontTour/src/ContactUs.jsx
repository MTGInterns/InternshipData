export default function contact(){
    return (
        <>
          <h1>Contact for any queries</h1>
        </>
    );
}