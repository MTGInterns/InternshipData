export default function tour(){
  return(
    <h1>Tours</h1>
  )
}