import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

export default function Subcategory(){
    const location = useLocation();
    const navigate = useNavigate();
    const { selectedCategory, allCategories } = location.state || {};
   
    const handleBackClick = () => {
        navigate(-1); 
        
    };

    return(
        <div className="container">
            <button className="btn btn-outline-secondary mt-3 mb-2" onClick={handleBackClick}>← Back</button>
            
            {selectedCategory && (
                <div className="text-center mb-5">
                    <h1 className="display-4" style={{ color: "#1a472a" }}>
                        {selectedCategory.title}
                    </h1>
                    <p className="lead">{selectedCategory.description}</p>
                </div>
            )}

            <div className="row mb-5">
              
                <div className="col-md-6 col-lg-3 mb-4">
                    <div className="card h-100 shadow-sm">
                        <img 
                            src="https://dynamic.tourtravelworld.com/blog_images/12-evergreen-hill-stations-in-kerala-20170724042237.jpg" 
                            className="card-img-top" 
                            alt="Hill Station" 
                            style={{ height: "200px", objectFit: "cover" }}
                        />
                        <div className="card-body">
                            <h5 className="card-title">Hill Station</h5>
                            <button className="btn btn-outline-success btn-sm">View More</button>
                        </div>
                    </div>
                </div>

                <div className="col-md-6 col-lg-3 mb-4">
                    <div className="card h-100 shadow-sm">
                        <img 
                            src="https://www.honeymoonbug.com/blog/wp-content/uploads/2022/04/Best-Houseboat-and-Backwater-Destinations-in-Kerala.jpg" 
                            className="card-img-top" 
                            alt="Backwaters" 
                            style={{ height: "200px", objectFit: "cover" }}
                        />
                        <div className="card-body">
                            <h5 className="card-title">Backwaters</h5>
                            <button className="btn btn-outline-success btn-sm">View More</button>
                        </div>
                    </div>
                </div>
                <div className="col-md-6 col-lg-3 mb-4">
                    <div className="card h-100 shadow-sm">
                        <img 
                            src="https://imagedelivery.net/y9EHf1toWJTBqJVsQzJU4g/www.indianholiday.com/2025/06/kerala-wildlife-v4.jpg/w=819" 
                            className="card-img-top" 
                            alt="Wildlife Sanctuaries" 
                            style={{ height: "200px", objectFit: "cover" }}
                        />
                        <div className="card-body">
                            <h5 className="card-title">Wildlife Sanctuaries</h5>
                            <button className="btn btn-outline-success btn-sm">View More</button>
                        </div>
                    </div>
                </div>

                <div className="col-md-6 col-lg-3 mb-4">
                    <div className="card h-100 shadow-sm">
                        <img 
                            src="https://www.atdcalleppey.com/wp-content/uploads/2019/10/Ecotourism-Destinations-in-Kerala.png" 
                            className="card-img-top" 
                            alt="Forests & Eco-Tourism" 
                            style={{ height: "200px", objectFit: "cover" }}
                        />
                        <div className="card-body">
                            <h5 className="card-title">Forests & Eco-Tourism</h5>
                            <button className="btn btn-outline-success btn-sm">View More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

