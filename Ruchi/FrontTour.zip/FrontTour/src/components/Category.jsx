import React from "react";
import { useNavigate } from "react-router-dom";

export default function Category() {
    const navigate = useNavigate();
    
    const cards = [
        {
            id: 0,
            title: "Nature & Wildlife",
            img: "https://keralaroutesuk.home.blog/wp-content/uploads/2019/07/explore-wildlife-sanctuaries-of-kerala-1.png",
            description: "Discover the beauty of nature and wildlife in Kerala.",

        },
        {
            id: 1,
            title: "Culture & Heritage",  
            img: "https://keralaroutesuk.home.blog/wp-content/uploads/2019/07/explore-cultural-heritage-of-kerala-1.png",
            description: "Experience the rich cultural heritage of Kerala.",
      
        },
        {
            id: 2,
            title: "Beaches & Coastal",
            img: "https://keralaroutesuk.home.blog/wp-content/uploads/2019/07/explore-beaches-of-kerala-1.png",
            description: "Relax and unwind on the beaches of Kerala.",
          
        }, 
        {
            id: 3,
            title: "Adventure",
            img: "https://keralaroutesuk.home.blog/wp-content/uploads/2019/07/explore-adventure-activities-of-kerala-1.png",
            description: "Embark on thrilling adventures in Kerala.",
         
        }, 
        {
            id: 4,
            title: "Wellness & Ayurveda",
            img: "https://keralaroutesuk.home.blog/wp-content/uploads/2019/07/explore-wellness-of-kerala-1.png",
            description: "Relax and rejuvenate in the wellness of Kerala.",
        
        },
        {
            id: 5,
            title: "Pilgrimage & Spiritual",
            img: "https://keralaroutesuk.home.blog/wp-content/uploads/2019/07/explore-pilgrimage-of-kerala-1.png",
            description: "Embark on spiritual pilgrimages in Kerala.",
           
        },
        {
            id: 6,
            title: "Tea & Spice Tours",
            img: "https://keralaroutesuk.home.blog/wp-content/uploads/2019/07/explore-tea-spice-tours-of-kerala-1.png",
            description: "Discover the tea and spice heritage of Kerala.",
         
        },        
    ];

    const handleCardClick = (card) => {
        navigate('/subcategory', { 
            state: { 
                selectedCategory: card,
                allCategories: cards 
            } 
        });
    };

    return (
      <div className="container">
        <div className="row g-4 mt-2">
          <h2 className="text-center" style={{textAlign:"center", fontWeight:"bold", fontSize:"40px", color:"black", marginBottom:"20px"}}>Explore Kerala</h2>
          
          {/* Nature & Wildlife Card */}
          <div className="col-md-6">
            <div className="card shadow-lg border-2 h-100" style={{ cursor: "pointer", borderRadius: "15px", overflow: "hidden" }}>
              <img 
                src="https://keralaroutesuk.home.blog/wp-content/uploads/2019/07/explore-wildlife-sanctuaries-of-kerala-1.png" 
                className="card-img-top" 
                alt="Wildlife Sanctuaries of Kerala"
                style={{ height: "350px", objectFit: "cover" }}
              />
              <div className="card-body d-flex flex-column" style={{ backgroundColor: "#f8f9fa" }}>
                <h5 className="card-title text-muted mb-2" style={{ fontSize: "0.9rem", letterSpacing: "1px" }}>
                  Nature & Wildlife
                </h5>
                <h4 className="card-title mb-3" style={{ fontWeight: "bold", color: "#1a472a" }}>
                  Explore wildlife sanctuaries of Kerala
                </h4>
                <div className="mt-auto">
                  <button 
                    className="btn btn-success px-4 py-2 custom-hover" 
                    style={{ borderRadius: "25px", fontWeight: "600" }} 
                    onClick={() => handleCardClick(cards[0])}
                  >
                    Explore
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Culture & Heritage Card */}
          <div className="col-md-6">
            <div className="card shadow-lg border-2 h-100" style={{ cursor: "pointer", borderRadius: "15px", overflow: "hidden" }}>
              <img 
                src="https://www.ritiriwaz.com/wp-content/uploads/2019/01/Kerala-culture.jpg" 
                className="card-img-top" 
                alt="Kerala Culture and Tradition"
                style={{ height: "350px", objectFit: "cover" }}
              />
              <div className="card-body d-flex flex-column" style={{ backgroundColor: "#f8f9fa" }}>
                <h5 className="card-title text-muted mb-2" style={{ fontSize: "0.9rem", letterSpacing: "1px" }}>
                  Culture & Heritage
                </h5>
                <h4 className="card-title mb-3" style={{ fontWeight: "bold", color: "#1a472a" }}>
                  Kerala Culture and Tradition
                </h4>
                <div className="mt-auto">
                  <button 
                    className="btn btn-warning px-4 py-2 custom-hover" 
                    style={{ borderRadius: "25px", fontWeight: "600", backgroundColor: "#1a472a", border: "none", color: "white" }} 
                    onClick={() => handleCardClick(cards[1])}
                  >
                    Explore
                  </button>
                </div>
              </div>
            </div>
          </div>
        
          {/* Beaches & Coastal */}
          <div className="col-md-6">
            <div className="card shadow-lg border-2 h-100" style={{ cursor: "pointer", borderRadius: "15px", overflow: "hidden" }}>
              <img 
                src="https://upload.wikimedia.org/wikipedia/commons/0/0e/01KovalamBeach%26Kerala.jpg" 
                className="card-img-top" 
                alt="Kerala Beaches"
                style={{ height: "350px", objectFit: "cover" }}
              />
              <div className="card-body d-flex flex-column" style={{ backgroundColor: "#f8f9fa" }}>
                <h5 className="card-title text-muted mb-2" style={{ fontSize: "0.9rem", letterSpacing: "1px" }}>
                  Beaches & Coastal
                </h5>
                <h4 className="card-title mb-3" style={{ fontWeight: "bold", color: "#1a472a" }}>
                  Kerala's Coastal Beauty
                </h4>
                <div className="mt-auto">
                  <button 
                    className="btn btn-success px-4 py-2 custom-hover" 
                    style={{ borderRadius: "25px", fontWeight: "600", backgroundColor: "#1a472a"}} 
                    onClick={() => handleCardClick(cards[2])}
                  >
                    Explore
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Adventure & Activities*/}
          <div className="col-md-6">
            <div className="card shadow-lg border-2 h-100" style={{ cursor: "pointer", borderRadius: "15px", overflow: "hidden" }}>
              <img 
                src="https://www.honeymoonbug.com/blog/wp-content/uploads/2022/03/Adventure-Activities-in-Kerala.jpg" 
                className="card-img-top" 
                alt="Adventure in Kerala"
                style={{ height: "350px", objectFit: "cover" }}
              />
              <div className="card-body d-flex flex-column" style={{ backgroundColor: "#f8f9fa" }}>
                <h5 className="card-title text-muted mb-2" style={{ fontSize: "0.9rem", letterSpacing: "1px" }}>
                  Adventure & Activities
                </h5>
                <h4 className="card-title mb-3" style={{ fontWeight: "bold", color: "#1a472a" }}>
                  Embrace the Wild, Create Your Thrill
                </h4>
                <div className="mt-auto">
                  <button 
                    className="btn btn-warning px-4 py-2 custom-hover" 
                    onClick={() => handleCardClick(cards[3])} 
                    style={{ borderRadius: "25px", fontWeight: "600", backgroundColor: "#1a472a", border: "none", color: "white" }}
                  >
                    Explore
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Wellness & Ayurveda */}
          <div className="col-md-6">
            <div className="card shadow-lg border-2 h-100" style={{ cursor: "pointer", borderRadius: "15px", overflow: "hidden" }}>
              <img 
                src="https://www.ayurvedacollege.net/images/blogs/blog161.jpg" 
                className="card-img-top" 
                alt="Ayurveda in Kerala"
                style={{ height: "350px", objectFit: "cover" }}
              />
              <div className="card-body d-flex flex-column" style={{ backgroundColor: "#f8f9fa" }}>
                <h5 className="card-title text-muted mb-2" style={{ fontSize: "0.9rem", letterSpacing: "1px" }}>
                  Wellness & Ayurveda
                </h5>
                <h4 className="card-title mb-3" style={{ fontWeight: "bold", color: "#1a472a" }}>
                  Ancient Healing for Modern Living
                </h4>
                <div className="mt-auto">
                  <button 
                    className="btn btn-warning px-4 py-2 custom-hover" 
                    onClick={() => handleCardClick(cards[4])} 
                    style={{ borderRadius: "25px", fontWeight: "600", backgroundColor: "#1a472a", border: "none", color: "white" }}
                  >
                    Explore
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Pilgrimage & Spiritual */}
          <div className="col-md-6">
            <div className="card shadow-lg border-2 h-100" style={{ cursor: "pointer", borderRadius: "15px", overflow: "hidden" }}>
              <img 
                src="https://cdn.bluebirdtravels.in/wp-content/uploads/pilgrimage/kerala/pilgrimage-tourism-in-kerala-cover-pic-1140x530.jpg" 
                className="card-img-top" 
                alt="Pilgrimage in Kerala"
                style={{ height: "350px", objectFit: "cover" }}
              />
              <div className="card-body d-flex flex-column" style={{ backgroundColor: "#f8f9fa" }}>
                <h5 className="card-title text-muted mb-2" style={{ fontSize: "0.9rem", letterSpacing: "1px" }}>
                  Pilgrimage & Spiritual
                </h5>
                <h4 className="card-title mb-3" style={{ fontWeight: "bold", color: "#1a472a" }}>
                  Where Faith Meets Serenity
                </h4>
                <div className="mt-auto">
                  <button 
                    className="btn btn-warning px-4 py-2 custom-hover" 
                    onClick={() => handleCardClick(cards[5])} 
                    style={{ borderRadius: "25px", fontWeight: "600", backgroundColor: "#1a472a", border: "none", color: "white" }}
                  >
                    Explore
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Tea & Spice Tours*/}
          <div className="col-md-6">
            <div className="card shadow-lg border-2 h-100" style={{ cursor: "pointer", borderRadius: "15px", overflow: "hidden" }}>
              <img 
                src="https://media.tacdn.com/media/attractions-splice-spp-674x446/06/6f/12/92.jpg" 
                className="card-img-top" 
                alt="Tea & Spice Tours"
                style={{ height: "350px", objectFit: "cover" }}
              />
              <div className="card-body d-flex flex-column" style={{ backgroundColor: "#f8f9fa" }}>
                <h5 className="card-title text-muted mb-2" style={{ fontSize: "0.9rem", letterSpacing: "1px" }}>
                  Tea & Spice Tours
                </h5>
                <h4 className="card-title mb-3" style={{ fontWeight: "bold", color: "#1a472a" }}>
                  A Journey Through Flavors and Aromas
                </h4>
                <div className="mt-auto">
                  <button 
                    className="btn btn-warning px-4 py-2 custom-hover" 
                    onClick={() => handleCardClick(cards[6])} 
                    style={{ borderRadius: "25px", fontWeight: "600", backgroundColor: "#1a472a", border: "none", color: "white" }}
                  >
                    Explore
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
}