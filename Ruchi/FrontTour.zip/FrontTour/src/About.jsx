export default function about(){
    return (
        <>
          <h1>Know more about Kerela</h1>
        </>
    );
}